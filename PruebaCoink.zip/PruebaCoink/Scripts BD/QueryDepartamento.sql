SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Departamento]') AND type in (N'U'))
DROP TABLE [dbo].[Departamento]
GO
CREATE TABLE [dbo].[Departamento](
	[id_departamento] [int] IDENTITY(1,1) NOT NULL,
	[des_departament] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[id_departamento] ASC
)
) ON [PRIMARY]
GO
