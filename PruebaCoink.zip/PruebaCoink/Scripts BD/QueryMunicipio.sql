SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Municipio]') AND type in (N'U'))
DROP TABLE [dbo].[Municipio]
GO
CREATE TABLE [dbo].[Municipio](
	[id_municipio] [int] IDENTITY(1,1) NOT NULL,
	[des_municipio] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[id_municipio] ASC
)
) ON [PRIMARY]
GO
