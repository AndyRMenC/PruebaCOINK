﻿namespace EjercicioPrueba.Modelos.DTO
{
    public class DepartamentoDTO
    {
        public int IdDepartamento { get; set; }
        public string? DesDepartament { get; set; }
    }
}
