﻿namespace EjercicioPrueba.Modelos.DTO
{
    public class PaisDTO
    {
        public int IdPais { get; set; }
        public string? DesPais { get; set; }
    }
}
