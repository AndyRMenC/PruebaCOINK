﻿namespace EjercicioPrueba.Modelos.DTO
{
    public class MunicipioDTO
    {
        public int IdMunicipio { get; set; }
        public string? DesMunicipio { get; set; }
    }
}
