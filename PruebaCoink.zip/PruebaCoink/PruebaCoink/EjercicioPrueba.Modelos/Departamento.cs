﻿namespace EjercicioPrueba.Modelos;

public partial class Departamento
{
    public int IdDepartamento { get; set; }

    public string? DesDepartament { get; set; }

    public virtual ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();
}
