﻿namespace EjercicioPrueba.Modelos;

public partial class Municipio
{
    public int IdMunicipio { get; set; }

    public string? DesMunicipio { get; set; }

    public virtual ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();
}
