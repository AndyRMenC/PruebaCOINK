﻿namespace EjercicioPrueba.Modelos;

public partial class Usuario
{
    public int IdUsuario { get; set; }

    public string? Nombre { get; set; }

    public string? Telefono { get; set; }

    public string? Direccion { get; set; }

    public int? IdPais { get; set; }

    public int? IdDepartamento { get; set; }

    public int? IdMunicipio { get; set; }

    public virtual Departamento? IdDepartamentoNavigation { get; set; }

    public virtual Municipio? IdMunicipioNavigation { get; set; }

    public virtual Pais? IdPaisNavigation { get; set; }
}
