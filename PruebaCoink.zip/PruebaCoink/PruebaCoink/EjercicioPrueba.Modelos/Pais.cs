﻿namespace EjercicioPrueba.Modelos;

public partial class Pais
{
    public int IdPais { get; set; }

    public string? DesPais { get; set; }

    public virtual ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();
}
