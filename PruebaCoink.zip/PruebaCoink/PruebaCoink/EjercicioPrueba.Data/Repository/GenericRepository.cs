﻿using EjercicioPrueba.Data.Context;
using EjercicioPrueba.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EjercicioPrueba.Data.Repository
{
    public class GenericRepository<TModelo> : IGenericRepository<TModelo> where TModelo : class
    {
        private readonly PruebaCoinkContext _proyectoContext;

        public GenericRepository(PruebaCoinkContext proyectoContext)
        {
            _proyectoContext = proyectoContext;
        }

        public async Task<TModelo> Obtener(Expression<Func<TModelo, bool>> filtro)
        {
            try
            {
                return await _proyectoContext.Set<TModelo>().FirstOrDefaultAsync(filtro);
            }
            catch
            {
                throw;
            }
        }

        public async Task<TModelo> Crear(TModelo modelo)
        {
            try
            {
                _proyectoContext.Set<TModelo>().Add(modelo);
                await _proyectoContext.SaveChangesAsync();
                return modelo;
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> Editar(TModelo modelo)
        {
            try
            {
                _proyectoContext.Set<TModelo>().Update(modelo);
                await _proyectoContext.SaveChangesAsync();
                return true;
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> Eliminar(TModelo modelo)
        {
            try
            {
                _proyectoContext.Set<TModelo>().Remove(modelo);
                await _proyectoContext.SaveChangesAsync();
                return true;
            }
            catch
            {
                throw;
            }
        }

        public async Task<IQueryable<TModelo>> Consultar(Expression<Func<TModelo, bool>>? filtro = null)
        {
            try
            {
                if (filtro == null)
                    return _proyectoContext.Set<TModelo>();
                else
                    return _proyectoContext.Set<TModelo>().Where(filtro);
            }
            catch
            {
                throw;
            }
        }
    }
}
