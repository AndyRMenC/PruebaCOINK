﻿using Microsoft.EntityFrameworkCore;
using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Data.Context;

public partial class PruebaCoinkContext : DbContext
{
    public PruebaCoinkContext()
    {
    }

    public PruebaCoinkContext(DbContextOptions<PruebaCoinkContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Departamento> Departamentos { get; set; }

    public virtual DbSet<Municipio> Municipios { get; set; }

    public virtual DbSet<Pais> Pais { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Departamento>(entity =>
        {
            entity.HasKey(e => e.IdDepartamento).HasName("PK__Departam__64F37A167D0B0E31");

            entity.ToTable("Departamento");

            entity.Property(e => e.IdDepartamento).HasColumnName("id_departamento");
            entity.Property(e => e.DesDepartament)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("des_departament");
        });

        modelBuilder.Entity<Municipio>(entity =>
        {
            entity.HasKey(e => e.IdMunicipio).HasName("PK__Municipi__01C9EB9960ECED0E");

            entity.ToTable("Municipio");

            entity.Property(e => e.IdMunicipio).HasColumnName("id_municipio");
            entity.Property(e => e.DesMunicipio)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("des_municipio");
        });

        modelBuilder.Entity<Pais>(entity =>
        {
            entity.HasKey(e => e.IdPais).HasName("PK__Pais__0941A3A7C51853FF");

            entity.Property(e => e.IdPais).HasColumnName("id_pais");
            entity.Property(e => e.DesPais)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("des_pais");
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.IdUsuario).HasName("PK__Usuario__4E3E04AD4F6A5EB9");

            entity.ToTable("Usuario");

            entity.Property(e => e.IdUsuario).HasColumnName("id_usuario");
            entity.Property(e => e.Direccion)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("direccion");
            entity.Property(e => e.IdDepartamento).HasColumnName("id_departamento");
            entity.Property(e => e.IdMunicipio).HasColumnName("id_municipio");
            entity.Property(e => e.IdPais).HasColumnName("id_pais");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.Telefono)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("telefono");

            entity.HasOne(d => d.IdDepartamentoNavigation).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.IdDepartamento)
                .HasConstraintName("FK__Usuario__id_depa__3D5E1FD2");

            entity.HasOne(d => d.IdMunicipioNavigation).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.IdMunicipio)
                .HasConstraintName("FK__Usuario__id_muni__3E52440B");

            entity.HasOne(d => d.IdPaisNavigation).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.IdPais)
                .HasConstraintName("FK__Usuario__id_pais__3C69FB99");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
