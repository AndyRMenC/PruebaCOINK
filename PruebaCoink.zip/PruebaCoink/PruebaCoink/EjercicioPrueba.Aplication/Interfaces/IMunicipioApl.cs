﻿using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Interfaces
{
    public interface IMunicipioApl
    {
        Task<MunicipioDTO> ObtenerMunicipio(int idMunicipio);
        Task<MunicipioDTO> CrearMunicipio(MunicipioDTO municipio);
        Task<bool> EditarMunicipio(MunicipioDTO municipio);
        Task<bool> EliminarMunicipio(int idMunicipio);
        Task<List<MunicipioDTO>> ConsultarMunicipios();
    }
}
