﻿using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Interfaces
{
    public interface IPaisApl
    {
        Task<PaisDTO> ObtenerPais(int idPais);
        Task<PaisDTO> CrearPais(PaisDTO pais);
        Task<bool> EditarPais(PaisDTO pais);
        Task<bool> EliminarPais(int idPais);
        Task<List<PaisDTO>> ConsultarPaises();
    }
}
