﻿using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Interfaces
{
    public interface IUsuarioApl
    {
        Task<UsuarioDTO> ObtenerUsuario(int idUsuario);
        Task<UsuarioDTO> CrearUsuario(UsuarioDTO usuario);
        Task<bool> EditarUsuario(UsuarioDTO usuario);
        Task<bool> EliminarUsuario(int idUsuario);
        Task<List<UsuarioDTO>> ConsultarUsuarios();
    }
}
