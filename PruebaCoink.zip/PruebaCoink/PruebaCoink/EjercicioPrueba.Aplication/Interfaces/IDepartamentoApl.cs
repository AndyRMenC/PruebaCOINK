﻿using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Interfaces
{
    public interface IDepartamentoApl
    {
        Task<DepartamentoDTO> ObtenerDepartamento(int idDepartamento);
        Task<DepartamentoDTO> CrearDepartamento(DepartamentoDTO departamento);
        Task<bool> EditarDepartamento(DepartamentoDTO departamento);
        Task<bool> EliminarDepartamento(int idDepartamento);
        Task<List<DepartamentoDTO>> ConsultarDepartamentos();
    }
}
