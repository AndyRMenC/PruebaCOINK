﻿using AutoMapper;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Modelos;
using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Main
{
    public class MunicipioApl : IMunicipioApl
    {
        private readonly IMunicipio _municipio;
        private readonly IMapper _mapper;

        public MunicipioApl(IMunicipio municipio, IMapper mapper)
        {
            _municipio = municipio;
            _mapper = mapper;
        }

        public async Task<MunicipioDTO> ObtenerMunicipio(int idMunicipio)
        {
            try
            {
                Municipio resMunicipio = await _municipio.ObtenerMunicipio(idMunicipio);
                return _mapper.Map<MunicipioDTO>(resMunicipio);
            }
            catch
            {
                throw;
            }
        }

        public async Task<MunicipioDTO> CrearMunicipio(MunicipioDTO municipio)
        {
            try
            {
                Municipio resMunicipio = await _municipio.CrearMunicipio(_mapper.Map<Municipio>(municipio));
                return _mapper.Map<MunicipioDTO>(resMunicipio);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarMunicipio(MunicipioDTO municipio)
        {
            try
            {
                return await _municipio.EditarMunicipio(_mapper.Map<Municipio>(municipio));
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarMunicipio(int idMunicipio)
        {
            try
            {
                return await _municipio.EliminarMunicipio(idMunicipio);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<MunicipioDTO>> ConsultarMunicipios()
        {
            try
            {
                List<Municipio> resMunicipios = await _municipio.ConsultarMunicipios();
                return _mapper.Map<List<MunicipioDTO>>(resMunicipios);
            }
            catch
            {
                throw;
            }
        }
    }
}
