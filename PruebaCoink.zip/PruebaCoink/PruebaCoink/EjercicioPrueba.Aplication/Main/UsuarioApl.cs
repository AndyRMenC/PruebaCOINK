﻿using AutoMapper;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Modelos;
using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Main
{
    public class UsuarioApl : IUsuarioApl
    {
        private readonly IDepartamento _departamento;
        private readonly IMunicipio _municipio;
        private readonly IPais _pais;
        private readonly IUsuario _usuario;
        private readonly IMapper _mapper;

        public UsuarioApl(IDepartamento departamento, IMunicipio municipio, IPais pais, IUsuario usuario, IMapper mapper)
        {
            _departamento = departamento;
            _municipio = municipio;
            _pais = pais;
            _usuario = usuario;
            _mapper = mapper;
        }

        public async Task<UsuarioDTO> ObtenerUsuario(int idUsuario)
        {
            try
            {
                Usuario resUsuario = await _usuario.ObtenerUsuario(idUsuario);
                return _mapper.Map<UsuarioDTO>(resUsuario);
            }
            catch
            {
                throw;
            }
        }

        public async Task<UsuarioDTO> CrearUsuario(UsuarioDTO usuario)
        {
            try
            {
                if (await Verificar(usuario))
                {
                    Usuario resUsuario = await _usuario.CrearUsuario(_mapper.Map<Usuario>(usuario));
                    return _mapper.Map<UsuarioDTO>(resUsuario);
                }
                return new UsuarioDTO();
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarUsuario(UsuarioDTO usuario)
        {
            try
            {
                if (await Verificar(usuario))
                {
                    return await _usuario.EditarUsuario(_mapper.Map<Usuario>(usuario));
                }
                return false;
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarUsuario(int idUsuario)
        {
            try
            {
                return await _usuario.EliminarUsuario(idUsuario);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<UsuarioDTO>> ConsultarUsuarios()
        {
            try
            {
                List<Usuario> resUsuarios = await _usuario.ConsultarUsuarios();
                return _mapper.Map<List<UsuarioDTO>>(resUsuarios);
            }
            catch
            {
                throw;
            }
        }

        private async Task<bool> Verificar(UsuarioDTO us)
        {
            var resDep = await _departamento.ObtenerDepartamento(Convert.ToInt32(us.IdDepartamento));
            var resMun = await _municipio.ObtenerMunicipio(Convert.ToInt32(us.IdMunicipio));
            var resPais = await _pais.ObtenerPais(Convert.ToInt32(us.IdPais));
            return true;
        }
    }
}
