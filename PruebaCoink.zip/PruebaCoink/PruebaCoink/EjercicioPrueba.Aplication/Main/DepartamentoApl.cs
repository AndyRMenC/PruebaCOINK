﻿using AutoMapper;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Modelos;
using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Main
{
    public class DepartamentoApl : IDepartamentoApl
    {
        private readonly IDepartamento _departamento;
        private readonly IMapper _mapper;

        public DepartamentoApl(IDepartamento departamento, IMapper mapper)
        {
            _departamento = departamento;
            _mapper = mapper;
        }

        public async Task<DepartamentoDTO> ObtenerDepartamento(int idDepartamento)
        {
            try
            {
                Departamento resDepartamento = await _departamento.ObtenerDepartamento(idDepartamento);
                return _mapper.Map<DepartamentoDTO>(resDepartamento);
            }
            catch
            {
                throw;
            }
        }

        public async Task<DepartamentoDTO> CrearDepartamento(DepartamentoDTO departamento)
        {
            try
            {
                Departamento resDepartamento = await _departamento.CrearDepartamento(_mapper.Map<Departamento>(departamento));
                return _mapper.Map<DepartamentoDTO>(resDepartamento);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarDepartamento(DepartamentoDTO departamento)
        {
            try
            {
                return await _departamento.EditarDepartamento(_mapper.Map<Departamento>(departamento));
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarDepartamento(int idDepartamento)
        {
            try
            {
                return await _departamento.EliminarDepartamento(idDepartamento);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<DepartamentoDTO>> ConsultarDepartamentos()
        {
            try
            {
                List<Departamento> resDepartamentos = await _departamento.ConsultarDepartamentos();
                return _mapper.Map<List<DepartamentoDTO>>(resDepartamentos);
            }
            catch
            {
                throw;
            }
        }
    }
}
