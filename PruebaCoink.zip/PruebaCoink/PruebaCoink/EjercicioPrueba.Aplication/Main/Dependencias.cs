﻿using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Business.Core;
using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Data.Context;
using EjercicioPrueba.Data.Interfaces;
using EjercicioPrueba.Data.Repository;
using EjercicioPrueba.Utilidades.Mapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EjercicioPrueba.Aplication.Main
{
    public static class Dependencias
    {
        public static void InyectarDependencias(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<PruebaCoinkContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("LocalConnection"));
            });

            services.AddTransient(typeof(IGenericRepository<>), typeof(GenericRepository<>));
            services.AddAutoMapper(typeof(AutoMapperProfile));

            services.AddScoped<IDepartamento, DepartamentoBusiness>();
            services.AddScoped<IMunicipio, MunicipioBusiness>();
            services.AddScoped<IPais, PaisBusiness>();
            services.AddScoped<IUsuario, UsuarioBusiness>();

            services.AddScoped<IDepartamentoApl, DepartamentoApl>();
            services.AddScoped<IMunicipioApl, MunicipioApl>();
            services.AddScoped<IPaisApl, PaisApl>();
            services.AddScoped<IUsuarioApl, UsuarioApl>();
        }
    }
}
