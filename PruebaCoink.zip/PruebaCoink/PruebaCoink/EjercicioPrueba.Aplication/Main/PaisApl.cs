﻿using AutoMapper;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Modelos;
using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Aplication.Main
{
    public class PaisApl : IPaisApl
    {
        private readonly IPais _pais;
        private readonly IMapper _mapper;

        public PaisApl(IPais pais, IMapper mapper)
        {
            _pais = pais;
            _mapper = mapper;
        }

        public async Task<PaisDTO> ObtenerPais(int idPais)
        {
            try
            {
                Pais resPais = await _pais.ObtenerPais(idPais);
                return _mapper.Map<PaisDTO>(resPais);
            }
            catch
            {
                throw;
            }
        }

        public async Task<PaisDTO> CrearPais(PaisDTO pais)
        {
            try
            {
                Pais resPais = await _pais.CrearPais(_mapper.Map<Pais>(pais));
                return _mapper.Map<PaisDTO>(resPais);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarPais(PaisDTO pais)
        {
            try
            {
                return await _pais.EditarPais(_mapper.Map<Pais>(pais));
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarPais(int idPais)
        {
            try
            {
                return await _pais.EliminarPais(idPais);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<PaisDTO>> ConsultarPaises()
        {
            try
            {
                List<Pais> resPaises = await _pais.ConsultarPaises();
                return _mapper.Map<List<PaisDTO>>(resPaises);
            }
            catch
            {
                throw;
            }
        }
    }
}
