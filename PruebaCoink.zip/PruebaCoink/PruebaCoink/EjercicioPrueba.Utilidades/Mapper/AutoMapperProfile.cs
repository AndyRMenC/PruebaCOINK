﻿using AutoMapper;
using EjercicioPrueba.Modelos;
using EjercicioPrueba.Modelos.DTO;

namespace EjercicioPrueba.Utilidades.Mapper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Departamento, DepartamentoDTO>().ReverseMap();

            CreateMap<Municipio, MunicipioDTO>().ReverseMap();

            CreateMap<Pais, PaisDTO>().ReverseMap();

            CreateMap<Usuario, UsuarioDTO>();

            CreateMap<UsuarioDTO, Usuario>()
                .ForMember(des => des.IdDepartamentoNavigation, opt => opt.Ignore())
                .ForMember(des => des.IdMunicipioNavigation, opt => opt.Ignore())
                .ForMember(des => des.IdPaisNavigation, opt => opt.Ignore());
        }
    }
}
