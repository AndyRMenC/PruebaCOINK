﻿namespace EjercicioPrueba.API.Utilidad
{
    public class Response<T>
    {
        public bool status { get; set; }
        public T? datos { get; set; }
        public string? msg { get; set; }
    }
}
