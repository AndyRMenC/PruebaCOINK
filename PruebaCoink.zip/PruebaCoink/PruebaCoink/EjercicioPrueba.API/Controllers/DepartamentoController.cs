﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Modelos.DTO;
using EjercicioPrueba.API.Utilidad;

namespace EjercicioPrueba.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartamentoController : ControllerBase
    {
        private readonly IDepartamentoApl _departamentoApl;

        public DepartamentoController(IDepartamentoApl departamentoApl)
        {
            _departamentoApl = departamentoApl;
        }

        [HttpGet]
        [Route("Consultar/{id:int}")]
        public async Task<IActionResult> Consultar(int id)
        {
            var rsp = new Response<DepartamentoDTO>();
            try
            {
                rsp.datos = await _departamentoApl.ObtenerDepartamento(id);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPost]
        [Route("Crear")]
        public async Task<IActionResult> Crear([FromBody] DepartamentoDTO departamento)
        {
            var rsp = new Response<DepartamentoDTO>();
            try
            {
                rsp.datos = await _departamentoApl.CrearDepartamento(departamento);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPut]
        [Route("Editar")]
        public async Task<IActionResult> Editar([FromBody] DepartamentoDTO departamento)
        {
            var rsp = new Response<DepartamentoDTO>();
            try
            {
                rsp.datos = departamento;
                rsp.status = await _departamentoApl.EditarDepartamento(departamento);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpDelete]
        [Route("Eliminar/{id:int}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            var rsp = new Response<DepartamentoDTO>();
            try
            {
                rsp.datos = await _departamentoApl.ObtenerDepartamento(id);
                rsp.status = await _departamentoApl.EliminarDepartamento(id);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpGet]
        [Route("Listar")]
        public async Task<IActionResult> Listar()
        {
            var rsp = new Response<List<DepartamentoDTO>>();
            try
            {
                rsp.datos = await _departamentoApl.ConsultarDepartamentos();
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }
    }
}
