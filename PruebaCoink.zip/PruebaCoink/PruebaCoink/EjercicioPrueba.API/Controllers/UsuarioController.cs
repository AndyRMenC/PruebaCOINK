﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Modelos.DTO;
using EjercicioPrueba.API.Utilidad;

namespace EjercicioPrueba.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioApl _usuarioApl;

        public UsuarioController(IUsuarioApl usuarioApl)
        {
            _usuarioApl = usuarioApl;
        }

        [HttpGet]
        [Route("Consultar/{id:int}")]
        public async Task<IActionResult> Consultar(int id)
        {
            var rsp = new Response<UsuarioDTO>();
            try
            {
                rsp.datos = await _usuarioApl.ObtenerUsuario(id);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPost]
        [Route("Crear")]
        public async Task<IActionResult> Crear([FromBody] UsuarioDTO usuario)
        {
            var rsp = new Response<UsuarioDTO>();
            try
            {
                rsp.datos = await _usuarioApl.CrearUsuario(usuario);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPut]
        [Route("Editar")]
        public async Task<IActionResult> Editar([FromBody] UsuarioDTO usuario)
        {
            var rsp = new Response<UsuarioDTO>();
            try
            {
                rsp.datos = usuario;
                rsp.status = await _usuarioApl.EditarUsuario(usuario);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpDelete]
        [Route("Eliminar/{id:int}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            var rsp = new Response<UsuarioDTO>();
            try
            {
                rsp.datos = await _usuarioApl.ObtenerUsuario(id);
                rsp.status = await _usuarioApl.EliminarUsuario(id);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpGet]
        [Route("Listar")]
        public async Task<IActionResult> Listar()
        {
            var rsp = new Response<List<UsuarioDTO>>();
            try
            {
                rsp.datos = await _usuarioApl.ConsultarUsuarios();
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }
    }
}
