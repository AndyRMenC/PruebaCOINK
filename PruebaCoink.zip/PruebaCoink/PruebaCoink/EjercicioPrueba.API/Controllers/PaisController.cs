﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Modelos.DTO;
using EjercicioPrueba.API.Utilidad;

namespace EjercicioPrueba.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaisController : ControllerBase
    {
        private readonly IPaisApl _paisApl;

        public PaisController(IPaisApl paisApl)
        {
            _paisApl = paisApl;
        }

        [HttpGet]
        [Route("Consultar/{id:int}")]
        public async Task<IActionResult> Consultar(int id)
        {
            var rsp = new Response<PaisDTO>();
            try
            {
                rsp.datos = await _paisApl.ObtenerPais(id);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPost]
        [Route("Crear")]
        public async Task<IActionResult> Crear([FromBody] PaisDTO pais)
        {
            var rsp = new Response<PaisDTO>();
            try
            {
                rsp.datos = await _paisApl.CrearPais(pais);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPut]
        [Route("Editar")]
        public async Task<IActionResult> Editar([FromBody] PaisDTO pais)
        {
            var rsp = new Response<PaisDTO>();
            try
            {
                rsp.datos = pais;
                rsp.status = await _paisApl.EditarPais(pais);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpDelete]
        [Route("Eliminar/{id:int}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            var rsp = new Response<PaisDTO>();
            try
            {
                rsp.datos = await _paisApl.ObtenerPais(id);
                rsp.status = await _paisApl.EliminarPais(id);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpGet]
        [Route("Listar")]
        public async Task<IActionResult> Listar()
        {
            var rsp = new Response<List<PaisDTO>>();
            try
            {
                rsp.datos = await _paisApl.ConsultarPaises();
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }
    }
}
