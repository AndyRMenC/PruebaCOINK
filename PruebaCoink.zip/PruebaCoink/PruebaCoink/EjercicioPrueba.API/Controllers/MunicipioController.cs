﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EjercicioPrueba.Aplication.Interfaces;
using EjercicioPrueba.Modelos.DTO;
using EjercicioPrueba.API.Utilidad;

namespace EjercicioPrueba.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MunicipioController : ControllerBase
    {
        private readonly IMunicipioApl _municipioApl;

        public MunicipioController(IMunicipioApl municipioApl)
        {
            _municipioApl = municipioApl;
        }

        [HttpGet]
        [Route("Consultar/{id:int}")]
        public async Task<IActionResult> Consultar(int id)
        {
            var rsp = new Response<MunicipioDTO>();
            try
            {
                rsp.datos = await _municipioApl.ObtenerMunicipio(id);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPost]
        [Route("Crear")]
        public async Task<IActionResult> Crear([FromBody] MunicipioDTO municipio)
        {
            var rsp = new Response<MunicipioDTO>();
            try
            {
                rsp.datos = await _municipioApl.CrearMunicipio(municipio);
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpPut]
        [Route("Editar")]
        public async Task<IActionResult> Editar([FromBody] MunicipioDTO municipio)
        {
            var rsp = new Response<MunicipioDTO>();
            try
            {
                rsp.datos = municipio;
                rsp.status = await _municipioApl.EditarMunicipio(municipio);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpDelete]
        [Route("Eliminar/{id:int}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            var rsp = new Response<MunicipioDTO>();
            try
            {
                rsp.datos = await _municipioApl.ObtenerMunicipio(id);
                rsp.status = await _municipioApl.EliminarMunicipio(id);
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

        [HttpGet]
        [Route("Listar")]
        public async Task<IActionResult> Listar()
        {
            var rsp = new Response<List<MunicipioDTO>>();
            try
            {
                rsp.datos = await _municipioApl.ConsultarMunicipios();
                rsp.status = true;
                rsp.msg = "Ok";
            }
            catch (Exception ex)
            {
                rsp.status = false;
                rsp.msg = ex.Message;
            }
            return Ok(rsp);
        }

    }
}
