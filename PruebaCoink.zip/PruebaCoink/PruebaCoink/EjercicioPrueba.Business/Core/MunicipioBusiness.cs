﻿using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Data.Interfaces;
using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Business.Core
{
    public class MunicipioBusiness : IMunicipio
    {
        private readonly IGenericRepository<Municipio> _municipioRepository;

        public MunicipioBusiness(IGenericRepository<Municipio> municipioRepository)
        {
            _municipioRepository = municipioRepository;
        }

        public async Task<Municipio> ObtenerMunicipio(int idMunicipio)
        {
            try
            {
                var queryMunicipio = await _municipioRepository.Obtener(m => m.IdMunicipio == idMunicipio);
                if (queryMunicipio == null)
                    throw new TaskCanceledException("El Municipio NO existe.");
                return queryMunicipio;
            }
            catch
            {
                throw;
            }
        }

        public async Task<Municipio> CrearMunicipio(Municipio municipio)
        {
            try
            {
                var queryMunicipio = await _municipioRepository.Crear(municipio);
                if (queryMunicipio.IdMunicipio == 0)
                    throw new TaskCanceledException("El Municipio NO pudo ser creado.");
                return await _municipioRepository.Obtener(m => m.IdMunicipio == queryMunicipio.IdMunicipio);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarMunicipio(Municipio municipio)
        {
            try
            {
                var queryMunicipio = await _municipioRepository.Obtener(m => m.IdMunicipio == municipio.IdMunicipio);
                if (queryMunicipio == null)
                    throw new TaskCanceledException("El Municipio NO existe.");
                return await _municipioRepository.Editar(municipio);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarMunicipio(int idMunicipio)
        {
            try
            {
                var queryMunicipio = await _municipioRepository.Obtener(m => m.IdMunicipio == idMunicipio);
                if (queryMunicipio == null)
                    throw new TaskCanceledException("El Municipio NO existe.");
                return await _municipioRepository.Eliminar(queryMunicipio);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<Municipio>> ConsultarMunicipios()
        {
            try
            {
                var queryMunicipios = await _municipioRepository.Consultar();
                return queryMunicipios.ToList();
            }
            catch
            {
                throw;
            }
        }
    }
}
