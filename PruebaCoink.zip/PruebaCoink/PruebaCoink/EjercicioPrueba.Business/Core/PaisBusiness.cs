﻿using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Data.Interfaces;
using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Business.Core
{
    public class PaisBusiness : IPais
    {
        private readonly IGenericRepository<Pais> _paisRepository;

        public PaisBusiness(IGenericRepository<Pais> paisRepository)
        {
            _paisRepository = paisRepository;
        }

        public async Task<Pais> ObtenerPais(int idPais)
        {
            try
            {
                var queryPais = await _paisRepository.Obtener(p => p.IdPais == idPais);
                if (queryPais == null)
                    throw new TaskCanceledException("El Pais NO existe.");
                return queryPais;
            }
            catch
            {
                throw;
            }
        }

        public async Task<Pais> CrearPais(Pais pais)
        {
            try
            {
                var queryPais = await _paisRepository.Crear(pais);
                if (queryPais.IdPais == 0)
                    throw new TaskCanceledException("El Pais NO pudo ser creado.");
                return await _paisRepository.Obtener(p => p.IdPais == queryPais.IdPais);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarPais(Pais pais)
        {
            try
            {
                var queryPais = await _paisRepository.Obtener(p => p.IdPais == pais.IdPais);
                if (queryPais == null)
                    throw new TaskCanceledException("El Pais NO existe.");
                return await _paisRepository.Editar(pais);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarPais(int idPais)
        {
            try
            {
                var queryPais = await _paisRepository.Obtener(p => p.IdPais == idPais);
                if (queryPais == null)
                    throw new TaskCanceledException("El Pais NO existe.");
                return await _paisRepository.Eliminar(queryPais);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<Pais>> ConsultarPaises()
        {
            try
            {
                var queryPaises = await _paisRepository.Consultar();
                return queryPaises.ToList();
            }
            catch
            {
                throw;
            }
        }
    }
}
