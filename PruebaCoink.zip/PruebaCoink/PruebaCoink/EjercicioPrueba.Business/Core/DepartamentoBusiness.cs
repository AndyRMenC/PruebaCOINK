﻿using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Data.Interfaces;
using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Business.Core
{
    public class DepartamentoBusiness : IDepartamento
    {
        private readonly IGenericRepository<Departamento> _departamentoRepository;

        public DepartamentoBusiness(IGenericRepository<Departamento> departamentoRepository)
        {
            _departamentoRepository = departamentoRepository;
        }

        public async Task<Departamento> ObtenerDepartamento(int idDepartamento)
        {
            try
            {
                var queryDepartamento = await _departamentoRepository.Obtener(d => d.IdDepartamento == idDepartamento);
                if (queryDepartamento == null)
                    throw new TaskCanceledException("El Departamento NO existe.");
                return queryDepartamento;
            }
            catch
            {
                throw;
            }
        }

        public async Task<Departamento> CrearDepartamento(Departamento departamento)
        {
            try
            {
                var queryDepartamento = await _departamentoRepository.Crear(departamento);
                if (queryDepartamento.IdDepartamento == 0)
                    throw new TaskCanceledException("El Departamento NO pudo ser creado.");
                return await _departamentoRepository.Obtener(d => d.IdDepartamento == queryDepartamento.IdDepartamento);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarDepartamento(Departamento departamento)
        {
            try
            {
                var queryDepartamento = await _departamentoRepository.Obtener(d => d.IdDepartamento == departamento.IdDepartamento);
                if (queryDepartamento == null)
                    throw new TaskCanceledException("El Departamento NO existe.");
                return await _departamentoRepository.Editar(departamento);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarDepartamento(int idDepartamento)
        {
            try
            {
                var queryDepartamento = await _departamentoRepository.Obtener(d => d.IdDepartamento == idDepartamento);
                if (queryDepartamento == null)
                    throw new TaskCanceledException("El Departamento NO existe.");
                return await _departamentoRepository.Eliminar(queryDepartamento);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<Departamento>> ConsultarDepartamentos()
        {
            try
            {
                var queryDepartamentos = await _departamentoRepository.Consultar();
                return queryDepartamentos.ToList();
            }
            catch
            {
                throw;
            }
        }
    }
}
