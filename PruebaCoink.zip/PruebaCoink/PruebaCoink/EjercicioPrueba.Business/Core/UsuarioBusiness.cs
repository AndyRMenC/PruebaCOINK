﻿using EjercicioPrueba.Business.Interfaces;
using EjercicioPrueba.Data.Interfaces;
using EjercicioPrueba.Modelos;
using Microsoft.EntityFrameworkCore;

namespace EjercicioPrueba.Business.Core
{
    public class UsuarioBusiness : IUsuario
    {
        private readonly IGenericRepository<Usuario> _usuarioRepository;

        public UsuarioBusiness(IGenericRepository<Usuario> usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        public async Task<Usuario> ObtenerUsuario(int idUsuario)
        {
            try
            {
                var queryUsuario = await _usuarioRepository.Obtener(u => u.IdUsuario == idUsuario);
                if (queryUsuario == null)
                    throw new TaskCanceledException("El Usuario NO existe.");
                return queryUsuario;
            }
            catch
            {
                throw;
            }
        }

        public async Task<Usuario> CrearUsuario(Usuario usuario)
        {
            try
            {
                var queryUsuario = await _usuarioRepository.Crear(usuario);
                if (queryUsuario.IdUsuario == 0)
                    throw new TaskCanceledException("El Usuario NO pudo ser creado.");
                return await _usuarioRepository.Obtener(u => u.IdUsuario == queryUsuario.IdUsuario);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EditarUsuario(Usuario usuario)
        {
            try
            {
                var queryUsuario = await _usuarioRepository.Obtener(U => U.IdUsuario == usuario.IdUsuario);
                if (queryUsuario == null)
                    throw new TaskCanceledException("El Usuario NO existe.");
                return await _usuarioRepository.Editar(usuario);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> EliminarUsuario(int idUsuario)
        {
            try
            {
                var queryUsuario = await _usuarioRepository.Obtener(u => u.IdUsuario == idUsuario);
                if (queryUsuario == null)
                    throw new TaskCanceledException("El Usuario NO existe.");
                return await _usuarioRepository.Eliminar(queryUsuario);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<Usuario>> ConsultarUsuarios()
        {
            try
            {
                var queryUsuarios = await _usuarioRepository.Consultar();
                return queryUsuarios
                    .Include(d => d.IdDepartamentoNavigation)
                    .Include(m => m.IdMunicipioNavigation)
                    .Include(p => p.IdPaisNavigation)
                    .ToList();
            }
            catch
            {
                throw;
            }
        }
    }
}
