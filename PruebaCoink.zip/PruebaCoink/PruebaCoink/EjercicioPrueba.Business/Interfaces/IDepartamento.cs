﻿using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Business.Interfaces
{
    public interface IDepartamento
    {
        Task<Departamento> ObtenerDepartamento(int idDepartamento);
        Task<Departamento> CrearDepartamento(Departamento departamento);
        Task<bool> EditarDepartamento(Departamento departamento);
        Task<bool> EliminarDepartamento(int idDepartamento);
        Task<List<Departamento>> ConsultarDepartamentos();
    }
}
