﻿using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Business.Interfaces
{
    public interface IMunicipio
    {
        Task<Municipio> ObtenerMunicipio(int idMunicipio);
        Task<Municipio> CrearMunicipio(Municipio municipio);
        Task<bool> EditarMunicipio(Municipio municipio);
        Task<bool> EliminarMunicipio(int idMunicipio);
        Task<List<Municipio>> ConsultarMunicipios();
    }
}
