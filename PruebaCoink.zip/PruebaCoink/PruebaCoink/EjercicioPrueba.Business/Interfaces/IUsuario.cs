﻿using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Business.Interfaces
{
    public interface IUsuario
    {
        Task<Usuario> ObtenerUsuario(int idUsuario);
        Task<Usuario> CrearUsuario(Usuario usuario);
        Task<bool> EditarUsuario(Usuario usuario);
        Task<bool> EliminarUsuario(int idUsuario);
        Task<List<Usuario>> ConsultarUsuarios();
    }
}
