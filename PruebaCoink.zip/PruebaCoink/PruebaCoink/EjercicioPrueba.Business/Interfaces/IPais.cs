﻿using EjercicioPrueba.Modelos;

namespace EjercicioPrueba.Business.Interfaces
{
    public interface IPais
    {
        Task<Pais> ObtenerPais(int idPais);
        Task<Pais> CrearPais(Pais pais);
        Task<bool> EditarPais(Pais pais);
        Task<bool> EliminarPais(int idPais);
        Task<List<Pais>> ConsultarPaises();
    }
}
